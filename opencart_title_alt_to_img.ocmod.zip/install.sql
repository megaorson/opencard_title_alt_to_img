ALTER TABLE oc_product_description ADD COLUMN title_img VARCHAR(200);
ALTER TABLE oc_product_description ADD COLUMN alt_img VARCHAR(200);
ALTER TABLE oc_product_image ADD COLUMN title_img VARCHAR(200);
ALTER TABLE oc_product_image ADD COLUMN alt_img VARCHAR(200);